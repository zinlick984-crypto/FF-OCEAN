# REDS FF — Projeto Android

Projeto inicial de aplicativo Android para painel independente de configurações de Free Fire, com interface preto/roxo neon.

## O que funciona
- Telas de sensibilidade com controles deslizantes.
- Perfis de referência para UMP, MP40, M4A1, AWM e personalizado.
- Controles de referência para tamanho/transparência do HUD.
- Dicas de desempenho e bateria.
- Salvamento local e exportação de configuração JSON.
- Interface em português, projetada para celular.

## Limitações intencionais
O app não controla o Free Fire, não aplica configurações automaticamente no jogo, não desenha uma sobreposição sobre outros aplicativos e não lê/modifica memória ou arquivos do jogo. Os valores são referências para configurar manualmente.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `REDS_FF_Android` usando **Open**.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos de build: Android Studio recente, JDK 17 e Android SDK 35. O aplicativo usa WebView embutido e não precisa de permissões de internet ou arquivos.

## HyperOS / POCO C75
O projeto tem `minSdk 23` e foi pensado para Android moderno. O build final e a instalação devem ser testados no aparelho real. Não foi possível compilar/validar um APK neste ambiente, pois ele não possui Android SDK/Gradle instalados.
